char WIFI_SSID[] = "ZK-4F";
char WIFI_PASSWORD[] = "Grt123456";

// const char* WIFI_SSID = "wifiname";
// const char* WIFI_PASSWORD = "wifi-password";

// MQTT 配置
const char* MQTT_SERVER = "43.138.214.161";
const uint16_t MQTT_PORT = 1883;
const char* MQTT_TOPIC = "sensor/dht22/2/data";
const char* MQTT_TOPIC_DeviceInfo = "device/system/2/device_info";
const char* MQTT_USER = "hut";      // 如果需要认证
const char* MQTT_PASSWORD = "hut_db_chencc";  // 如果需要认证
const char* MQTT_CLIENT_ID = "ESP32ClientUniqueIDRwSFUw";